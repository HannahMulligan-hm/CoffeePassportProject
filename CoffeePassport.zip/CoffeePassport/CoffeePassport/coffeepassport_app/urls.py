from django.urls import path     
from . import views

urlpatterns = [
    path('', views.index),
    path('register', views.register),
    path('loggin', views.loggin),
    path('login', views.login),
    path('logout', views.logout),
    path('coffee/new', views.new),
    path('coffee/home', views.home),
    path('coffee/create', views.create),
    path('coffee/<int:coffeeCard_id>/edit', views.edit),
    path('coffee/<int:coffeeCard_id>/update', views.update),
    path('coffee/<int:coffeeCard_id>/delete', views.delete),
    path('coffee/profile/<int:user_id>', views.profile),
    path('coffee/profile/<int:user_id>/complete', views.complete),
    path('coffee/<int:coffeeCard_id>/view', views.view_card),
]

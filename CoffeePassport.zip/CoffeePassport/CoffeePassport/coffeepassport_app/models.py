from django.db import models
import re, bcrypt
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
# Create your models here.

# ---------------------------------------------------------------------------- #
#                               User Validations                               #
# ---------------------------------------------------------------------------- #
class UserManager(models.Manager):
# ---------------------------------------------------------------------------- #
#                                 Register page                                #
# ---------------------------------------------------------------------------- #
    def registration_validator(self,form):
        errors = {}
        if len(form['name']) < 1:
            errors["name"] = "Your name must not be blank."
# -------------------- email validator -------------------- #
        if len(form['email']) <1:
            errors['email'] = "Email cannot be blank."
        elif not EMAIL_REGEX.match(form['email']):
            errors['email'] = "Invalid email address."
        email_check = self.filter(email=form['email'])
        if email_check:
            errors['email'] = "Email already in use"
# ------------------ password validator ------------------- #
        if len(form['password']) < 8:
            errors['password'] = "Password cannot be less than 8 characters."
        elif form['password'] != form['confirm_password']:
            errors['password'] = "Passwords do not match."
        return errors
# ----------------------- login validator on login_page ---------------------- #
    def login_validator(self, postData):
        errors = {}
        check = User.objects.filter(email=postData['login_email'])
        if not check:
            errors['login_email'] = "No account found."
        else:
# ------------------- password checker ------------------- #
            if not bcrypt.checkpw(postData['login_password'].encode(), check[0].password.encode()):
                errors['login_email'] = "Incorrect password."
        return errors

# ---------------------------------------------------------------------------- #
#                                  User Class                                  #
# ---------------------------------------------------------------------------- #
class User(models.Model):
    name = models.CharField(max_length=200)
    email = models.CharField(max_length=200)
    password = models.CharField(max_length=255)
    fav_roast = models.CharField(max_length=200)
    bio = models.TextField()
    objects = UserManager()

# ---------------------------------------------------------------------------- #
#                             CoffeeCard Validator                             #
# ---------------------------------------------------------------------------- #
# --------------------------------- Dropdown --------------------------------- #
STATUS_CHOICES = [
    ('light', 'LIGHT'),
    ('medium', 'MEDIUM'),
    ('dark', 'DARK')
]
BREW_CHOICES = [
    ('')
]
# --------------------------------- Validator -------------------------------- #
class CoffeeCardManager(models.Manager):
    def object_validator(self,postData):
        errors = {}
        if len(postData['coffee_name']) < 1:
            errors['coffee_name'] = "Coffee Name must not be blank!"
        if len(postData['coffee_desc']) < 1:
            errors['coffee_desc'] = "Coffee Description must not be blank!"
        if len(postData['roast']) < 1:
            errors['roast'] = "Please select a roast!"
        if len(postData['origin']) < 1:
            errors['origin'] = "Coffee Name must not be blank!"
        return errors
# ---------------------------------------------------------------------------- #
#                               CoffeeCard Class                               #
# ---------------------------------------------------------------------------- #
class CoffeeCard(models.Model):
    coffee_name = models.CharField(max_length=100)
    coffee_desc = models.TextField()
    temp = models.CharField(max_length=200)
    roast = models.CharField(max_length=15, choices=STATUS_CHOICES, default='medium')
    origin = models.CharField(max_length=200)
    brew_method = models.CharField(max_length=200)
    creator = models.ForeignKey(User, related_name="creator", on_delete=models.CASCADE)
    likes = models.ManyToManyField(User, related_name="coffeeCards")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = CoffeeCardManager()
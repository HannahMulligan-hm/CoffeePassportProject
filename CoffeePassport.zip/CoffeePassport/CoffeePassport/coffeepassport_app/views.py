from django.shortcuts import render, HttpResponse, redirect
from django.contrib import messages
from .models import User, CoffeeCard
from django.urls import reverse
import bcrypt
# ---------------------------------------------------------------------------- #
#                               Registration Page                              #
# ---------------------------------------------------------------------------- #
def index(request):
    return render(request, "index.html")

def register(request):
    if request.method == "GET":
        return redirect('/')
    errors = User.objects.registration_validator(request.POST)
    if len(errors) >0:
        for key, value in errors.items():
            messages.error(request, value)
            return redirect('/')
    else:
        new_user = User.objects.create(
            name = request.POST['name'],
            email = request.POST['email'],
            password = bcrypt.hashpw(request.POST['password'].encode(), bcrypt.gensalt()).decode()
        )
        request.session['user_id'] = new_user.id
        messages.success(request, "You have successfully registered!")
        return redirect('coffee/home')
# ---------------------------------------------------------------------------- #
#                                  Login Page                                  #
# ---------------------------------------------------------------------------- #
def loggin(request):
    return render(request,"login.html")

def login(request):
    errors = User.objects.login_validator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/loggin')
    else:
        user = User.objects.get(email = request.POST['login_email'])
        request.session['user_id'] = user.id
        return redirect('coffee/home')
# ---------------------------------------------------------------------------- #
#                                 Profile Page                                 #
# ---------------------------------------------------------------------------- #
def profile(request, user_id):
    context = {
        'user': User.objects.get(id= user_id),
        'mine': user_id == request.session['user_id'],
        'card': CoffeeCard.objects.filter(creator= User.objects.get(id = user_id))
        }
    return render(request, "profile.html", context)
def complete(request, user_id):
        user = User.objects.get(id = request.session['user_id'])
        user.fav_roast = request.POST['roast']
        user.bio = request.POST['bio']
        user.save()
        return redirect("/coffee/home")
# ---------------------------------------------------------------------------- #
#                                   Home Page                                  #
# ---------------------------------------------------------------------------- #
def home(request):
    if 'user_id' not in request.session:
        return redirect('/')
    else:
        mine = CoffeeCard.objects.all()
        context = {
            'user': User.objects.get(id = request.session['user_id']),
            'posts': CoffeeCard.objects.all(),
            'creator': CoffeeCard.objects.filter(creator = request.session['user_id']), }
    return render(request, "home.html", context)
# ---------------------------------------------------------------------------- #
#                                 View one card                                #
# ---------------------------------------------------------------------------- #
def view_card(request, coffeeCard_id):
    if 'user_id' not in request.session:
        return redirect('/')
    else:
        post = CoffeeCard.objects.get(id = coffeeCard_id)
        context = {
            'user': User.objects.get(id= request.session['user_id']),
            'post': CoffeeCard.objects.get(id = coffeeCard_id),
            'blonde': post.roast == "blonde",
            'medium': post.roast == "medium",
            'dark': post.roast == "dark",
            'drip': post.brew_method == "drip",
            'pour-over': post.brew_method == "pour-over",
            'press': post.brew_method == "press",
            'other': post.brew_method == "other",
        }
    return render (request,"view.html", context)
# ---------------------------------------------------------------------------- #
#                          Creating a New Coffee Card                          #
# ---------------------------------------------------------------------------- #
def new(request):
    if 'user_id' not in request.session:
        return redirect('/')
    else:
        context = {
            "coffeeCard" : CoffeeCard.objects.all()
        }
        return render(request,"create_card.html", context)

def create(request):
    if request.method == "GET":
        return redirect('/')
    errors = CoffeeCard.objects.object_validator(request.POST)
    if len(errors) > 0:
        for key, value in errors.item():
            messages.error(request, value)
            return redirect('/coffee/new')
    else:
        user = User.objects.get(id = request.session['user_id'])
        new_object = CoffeeCard.objects.create(
            coffee_name = request.POST["coffee_name"],
            coffee_desc = request.POST["coffee_desc"],
            temp = request.POST["temp"],
            roast = request.POST["roast"],
            origin = request.POST["origin"],
            brew_method = request.POST["brew_method"],
            creator = user
        )
    return redirect("/coffee/home")
# ---------------------------------------------------------------------------- #
#                               Edit a CoffeeCard                              #
# ---------------------------------------------------------------------------- #
def edit(request, coffeeCard_id):
    if 'user_id' not in request.session:
        return redirect('/')
    else:
        creator = User.objects.get(id = request.session['user_id'])
        coffeeCard = CoffeeCard.objects.get(id = coffeeCard_id)
        context = {
            'creator': request.session['user_id'] == creator.id,
            "post" : coffeeCard
        }
        return render(request, "edit.html", context)
def update(request, coffeeCard_id):
    errors = CoffeeCard.objects.object_validator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
            return redirect('/coffee/'+str(coffeeCard_id)+'/edit')
    else:
        coffee = CoffeeCard.objects.get(id = coffeeCard_id)
        coffee.coffee_name = request.POST['coffee_name']
        coffee.coffee_desc = request.POST['coffee_desc']
        coffee.roast = request.POST['roast']
        coffee.origin = request.POST['origin']
        coffee.save()
        return redirect('/coffee/home')
# ---------------------------------------------------------------------------- #
#                              Delete Coffee Card                              #
# ---------------------------------------------------------------------------- #
def delete(request, coffeeCard_id):
    if 'user_id' not in request.session:
        return redirect('/')
    else:
        coffee = CoffeeCard.objects.get(id = coffeeCard_id)
        coffee.delete()
        return redirect('/coffee/home')
# ---------------------------------------------------------------------------- #
#                                    Logout                                    #
# ---------------------------------------------------------------------------- #
def logout(request):
    request.session.flush()
    return redirect('/')


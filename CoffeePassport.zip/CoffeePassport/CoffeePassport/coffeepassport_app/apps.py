from django.apps import AppConfig


class CoffeepassportAppConfig(AppConfig):
    name = 'coffeepassport_app'


function isChecked(){
    var checked = document.getElementsByName('brew_method').checked;

    if(checked == false){
        alert('Please select a brew method!');
        return false;
    }
    else{
        return true;
    }
}